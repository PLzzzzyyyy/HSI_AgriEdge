"""Offline algorithm identity checks: drift, portable paths and line endings."""
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from verify_1581_algorithm import verify


class BaselineTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        (self.root / 'gcs').mkdir()
        self.raw = b'fixed algorithm\n'
        (self.root / 'model.py').write_bytes(self.raw)
        self.profile = dict(algorithm='fixture', scope='offline', files=[dict(
            path='model.py', kind='text', sha256=hashlib.sha256(self.raw).hexdigest())])
        self.save()

    def save(self):
        (self.root / 'gcs/algorithm_1581.json').write_text(json.dumps(self.profile), encoding='utf-8')

    def test_lf_and_crlf_are_the_same_algorithm(self):
        self.assertTrue(verify(self.root)['ok'])
        (self.root / 'model.py').write_bytes(self.raw.replace(b'\n', b'\r\n'))
        self.assertTrue(verify(self.root)['ok'])

    def test_changed_algorithm_and_missing_file_are_rejected(self):
        (self.root / 'model.py').write_bytes(b'changed algorithm\n')
        self.assertFalse(verify(self.root)['ok'])
        (self.root / 'model.py').unlink()
        self.assertFalse(verify(self.root)['ok'])

    def test_weights_require_exact_bytes(self):
        self.profile['files'][0]['kind'] = 'binary'
        self.save()
        (self.root / 'model.py').write_bytes(self.raw.replace(b'\n', b'\r\n'))
        self.assertFalse(verify(self.root)['ok'])

    def test_absolute_and_parent_paths_are_rejected(self):
        for path in ('../model.py', '/model.py', 'C:/model.py', 'gcs\\model.py'):
            with self.subTest(path=path):
                self.profile['files'][0]['path'] = path
                self.save()
                self.assertFalse(verify(self.root)['ok'])


if __name__ == '__main__':
    unittest.main()
