"""Read-only check of the recovered 1581/v8 algorithm and canonical weights."""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parents[1]


def verify(root=ROOT):
    root = Path(root).resolve()
    profile = json.loads((root / 'gcs/algorithm_1581.json').read_text(encoding='utf-8'))
    errors = []
    checked = 0
    for row in profile['files']:
        relative = PurePosixPath(row['path'])
        if (relative.is_absolute() or '..' in relative.parts or ':' in row['path']
                or '\\' in row['path']):
            errors.append(dict(path=row['path'], reason='invalid relative path'))
            continue
        path = (root / Path(*relative.parts)).resolve()
        if not path.is_relative_to(root) or not path.is_file():
            errors.append(dict(path=row['path'], reason='missing or outside project'))
            continue
        raw = path.read_bytes()
        variants = [raw]
        if row['kind'] == 'text':
            lf = raw.replace(b'\r\n', b'\n')
            variants.extend((lf, lf.replace(b'\n', b'\r\n')))
        if not any(hashlib.sha256(data).hexdigest() == row['sha256'] for data in variants):
            errors.append(dict(path=row['path'], reason='1581 algorithm/weight mismatch'))
        checked += 1
    return dict(algorithm=profile['algorithm'], ok=not errors, checked_files=checked,
                errors=errors, scope=profile['scope'],
                unavailable_history=profile.get('unavailable_history', []))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=ROOT)
    args = parser.parse_args()
    result = verify(args.root)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result['ok'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
