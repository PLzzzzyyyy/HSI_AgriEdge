"""Read-only closed-loop prerequisites. No model loading, training or device I/O."""
import hashlib
import json
from pathlib import Path
import sys

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'model'))
import preprocess
import scenes
import board_models


def require(ok, message):
    if not ok:
        raise ValueError(message)


def file_record(path, role):
    path = Path(path).resolve()
    try:
        before = path.stat()
        with path.open('rb') as stream:
            digest = hashlib.file_digest(stream, 'sha256').hexdigest()
        after = path.stat()
    except OSError as exc:
        raise ValueError(f'Missing/unreadable {role}: {path}') from exc
    require(before.st_size > 0, f'Empty {role}: {path}')
    require((before.st_size, before.st_mtime_ns) == (after.st_size, after.st_mtime_ns),
            f'Input changed during preflight: {path}')
    return dict(role=role, path=str(path), bytes=after.st_size,
                mtime_ns=after.st_mtime_ns, sha256=digest)


def unchanged(receipt):
    for old in receipt['inputs']:
        current = file_record(old['path'], old['role'])
        require(current == old, f'Preflight input changed: {old["path"]}')


def preflight(root, scene, hold_class, *, model='unoverlapping', seed=0,
              per_class=100, val_per_class=10, annotate=30):
    root = Path(root).resolve(); spec = board_models.scene_spec(scene)
    ncls = spec['classes']; h, w = spec['shape']
    require(type(hold_class) is int and 1 <= hold_class <= ncls, 'Invalid hold class')
    require(type(seed) is int and type(per_class) is int and per_class > 1 and
            type(val_per_class) is int and 0 < val_per_class < per_class and
            type(annotate) is int and 0 < annotate <= per_class - val_per_class,
            'Invalid annotation/validation count; keep an independent Train holdout')
    loop = root / 'data/closed_loop' / scene
    inputs = [file_record(loop / 'region.json', 'region.json')]
    info = json.loads((loop / 'region.json').read_text(encoding='utf-8'))
    expected = dict(scene=scene, model=model, seed=seed, hold_class=hold_class,
                    official_train=f'Train{per_class}.mat', official_test=f'Test{per_class}.mat')
    require(all(info.get(k) == v for k, v in expected.items()), 'Registered training recipe identity differs')
    reg = info.get('region', {}); y, x, size = (reg.get(k) for k in ('row0', 'col0', 'size'))
    require(all(type(v) is int for v in (y, x, size)) and size == 64 and
            0 <= y <= h - size and 0 <= x <= w - size, 'Invalid registered region bounds/size')
    ckpt = root / 'data/ckpt' / f'{scene}_{model}_s{seed}_hold{hold_class}.pth'
    require(str(info.get('old_ckpt', '')).replace('\\', '/').split('/')[-1] == ckpt.name,
            'Old checkpoint filename/recipe differs')
    ck_record = file_record(ckpt, 'old checkpoint'); inputs.append(ck_record)
    require(ck_record['sha256'] == info.get('old_ckpt_sha256'), 'Old checkpoint SHA256 differs')
    candidate = board_models.load_candidate(root / 'data/scenes', scene, f'hold{hold_class}')
    require(candidate['provenance'].get('checkpoint_sha256') == ck_record['sha256'],
            'Old board package checkpoint binding differs')
    folder = root / 'data/scenes' / scene / 'weights' / f'hold{hold_class}'
    for name in [*(n for n, _ in board_models.part_files(scene)), 'weights_engine.bin', 'board_model.json']:
        inputs.append(file_record(folder / name, 'baseline package/' + name))

    arrays = {}
    for name in ('pred_old_region.bin', 'gt_region.bin'):
        record = file_record(loop / name, name); inputs.append(record)
        require(record['bytes'] == size * size, f'Wrong {name} byte count')
        a = np.fromfile(loop / name, np.uint8).reshape(size, size)
        require(a.max() <= ncls and (name != 'pred_old_region.bin' or a.min() > 0),
                f'Invalid baseline/GT labels in {name}')
        arrays[name] = a

    cube, gt_path = scenes.raw_paths(scene); train_path, test_path = scenes.split_paths(scene, per_class)
    paths = dict(cube=cube, gt=gt_path, train=train_path, test=test_path)
    for role, path in paths.items(): inputs.append(file_record(path, role))
    require(Path(train_path).name == expected['official_train'] and Path(test_path).name == expected['official_test'],
            'Official Train/Test filenames differ')
    raw_gt, train, test = (preprocess.load_mat(paths[k]) for k in ('gt', 'train', 'test'))
    for name, a in [('GT', raw_gt), ('Train', train), ('Test', test)]:
        require(a.shape == (h, w) and np.issubdtype(a.dtype, np.integer) and
                np.all((a >= 0) & (a <= ncls)), f'{name} labels/shape differ')
    gt, old = arrays['gt_region.bin'], arrays['pred_old_region.bin']
    require(np.array_equal(raw_gt[y:y + size, x:x + size], gt), 'GT crop differs from original GT')
    require(not np.any((train > 0) & (test > 0)) and
            all(int((train == c).sum()) == per_class for c in range(1, ncls + 1)) and
            np.array_equal(train[train > 0], raw_gt[train > 0]) and
            np.array_equal(test[test > 0], raw_gt[test > 0]), 'Official Train/Test partition binding differs')
    labeled, held = gt > 0, gt == hold_class
    require(labeled.any() and held.any() and int(held.sum()) == reg.get('hold_pixels'), 'GT region population differs')
    require(np.bincount(old.ravel(), minlength=ncls + 1).tolist() == info.get('old_region_pred_hist') and
            abs(float(np.mean(old[labeled] == gt[labeled])) - info.get('old_region_oa', float('nan'))) < 1e-12 and
            abs(float(np.mean(old[held] == hold_class)) - info.get('old_region_hold_recall', float('nan'))) < 1e-12,
            'Old prediction differs from registered baseline statistics')
    metrics = info.get('old_test', {})
    require(all(isinstance(metrics.get(k), (int, float)) and np.isfinite(metrics[k]) for k in ('OA', 'AA', 'Kappa')) and
            isinstance(metrics.get('per_class'), list) and len(metrics['per_class']) == ncls,
            'Missing registered old Test metrics needed by postprocessing')
    return dict(schema=1, scene=scene, recipe=expected, annotate=annotate,
                val_per_class=val_per_class, rect=[y, x, size, size], old_ckpt=str(ckpt.resolve()),
                inputs=inputs, scope='TRAINING_INPUT_PREFLIGHT_NOT_TRAINING_OR_BOARD_ACCEPTANCE')
