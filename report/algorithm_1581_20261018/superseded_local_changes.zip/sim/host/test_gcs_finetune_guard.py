"""Training gates and byte-equivalent export fixtures; no training/device calls."""
import copy
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

import numpy as np
from scipy.io import savemat

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / 'gcs'), str(ROOT / 'model')]
import board_models as models
import finetune_guard as guard
from sim.host.test_gcs_models import fixture


def exported(root, tag, checkpoint=b'old checkpoint', parts=None):
    folder = root / 'data/scenes/longkou/weights' / tag
    folder.mkdir(parents=True, exist_ok=True)
    companion, engine = parts or fixture('longkou')
    files = {}; offset = 0
    for name, size in models.part_files('longkou'):
        files[name] = companion[offset:offset + size]; offset += size
    files['weights_engine.bin'] = engine
    for name, raw in files.items():
        (folder / name).write_bytes(raw)
    meta = dict(schema=1, scene='longkou', tag=tag, checkpoint='fixture.pth',
                checkpoint_sha256=hashlib.sha256(checkpoint).hexdigest(),
                files={n: hashlib.sha256(b).hexdigest() for n, b in files.items()})
    (folder / 'board_model.json').write_text(json.dumps(meta), encoding='utf-8')
    return folder


class PreflightTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.loop = self.root / 'data/closed_loop/longkou'; self.loop.mkdir(parents=True)
        self.gt = ((np.arange(550 * 400) // 100) % 9 + 1).reshape(550, 400).astype(np.uint8)
        self.train = np.zeros_like(self.gt)
        for c in range(1, 10):
            self.train.flat[np.flatnonzero(self.gt == c)[:100]] = c
        self.test = np.where(self.train, 0, self.gt)
        self.paths = {k: self.root / n for k, n in [('cube', 'cube.mat'), ('gt', 'gt.mat'),
                      ('train', 'Train100.mat'), ('test', 'Test100.mat')]}
        self.paths['cube'].write_bytes(b'raw cube fixture, never preprocessed')
        for k, a in [('gt', self.gt), ('train', self.train), ('test', self.test)]:
            savemat(self.paths[k], {'data': a})
        crop = self.gt[:64, :64]; old = np.ones((64, 64), np.uint8)
        crop.tofile(self.loop / 'gt_region.bin'); old.tofile(self.loop / 'pred_old_region.bin')
        self.ckpt = self.root / 'data/ckpt/longkou_unoverlapping_s0_hold3.pth'
        self.ckpt.parent.mkdir(); self.ckpt.write_bytes(b'old checkpoint')
        self.info = dict(scene='longkou', model='unoverlapping', seed=0, hold_class=3,
            official_train='Train100.mat', official_test='Test100.mat',
            region=dict(row0=0, col0=0, size=64, hold_pixels=int((crop == 3).sum())),
            old_ckpt='D:/original/data/ckpt/' + self.ckpt.name,
            old_ckpt_sha256=hashlib.sha256(self.ckpt.read_bytes()).hexdigest(),
            old_region_pred_hist=np.bincount(old.ravel(), minlength=10).tolist(),
            old_region_oa=float(np.mean(old == crop)), old_region_hold_recall=0.,
            old_test=dict(OA=.1, AA=.1, Kappa=0., per_class=[.1] * 9))
        self.save_info(); exported(self.root, 'hold3')
        self.addCleanup(patch.stopall)
        patch.object(guard.scenes, 'raw_paths', return_value=(self.paths['cube'], self.paths['gt'])).start()
        patch.object(guard.scenes, 'split_paths', return_value=(self.paths['train'], self.paths['test'])).start()

    def save_info(self):
        (self.loop / 'region.json').write_text(json.dumps(self.info), encoding='utf-8')

    def check(self, **kwargs):
        return guard.preflight(self.root, 'longkou', 3, **kwargs)

    def test_receipt_binds_local_checkpoint_baseline_gt_and_official_splits(self):
        before = {p: p.read_bytes() for p in self.loop.iterdir()}
        result = self.check()
        self.assertEqual(result['old_ckpt'], str(self.ckpt.resolve()))
        self.assertEqual(result['rect'], [0, 0, 64, 64])
        self.assertEqual(result['scope'], 'TRAINING_INPUT_PREFLIGHT_NOT_TRAINING_OR_BOARD_ACCEPTANCE')
        self.assertGreaterEqual(len(result['inputs']), 9)
        self.assertEqual(before, {p: p.read_bytes() for p in self.loop.iterdir()})

    def test_missing_or_wrong_size_baselines_fail_before_training(self):
        for name in ['pred_old_region.bin', 'gt_region.bin']:
            with self.subTest(name=name):
                path = self.loop / name; saved = path.read_bytes(); path.write_bytes(saved[:-1])
                with self.assertRaisesRegex(ValueError, 'byte count'): self.check()
                path.unlink()
                with self.assertRaisesRegex(ValueError, name): self.check()
                path.write_bytes(saved)

    def test_changed_checkpoint_or_manifest_binding_is_rejected(self):
        self.ckpt.write_bytes(b'changed checkpoint')
        with self.assertRaisesRegex(ValueError, 'checkpoint'): self.check()
        self.ckpt.write_bytes(b'old checkpoint'); exported(self.root, 'hold3', b'wrong source')
        with self.assertRaisesRegex(ValueError, 'checkpoint'): self.check()

    def test_recipe_identity_and_region_bounds_are_strict(self):
        original = copy.deepcopy(self.info)
        for key, value in [('scene', 'honghu'), ('model', 'overlapping'), ('seed', 1),
                           ('hold_class', 4), ('official_train', 'Train50.mat')]:
            with self.subTest(key=key):
                self.info = copy.deepcopy(original); self.info[key] = value; self.save_info()
                with self.assertRaises(ValueError): self.check()
        self.info = original; self.info['region']['row0'] = 550; self.save_info()
        with self.assertRaisesRegex(ValueError, 'region'): self.check()

    def test_gt_crop_and_old_prediction_statistics_are_not_trusted_by_size(self):
        p = self.loop / 'gt_region.bin'; raw = p.read_bytes(); p.write_bytes(bytes([9]) + raw[1:])
        with self.assertRaisesRegex(ValueError, 'GT'): self.check()
        p.write_bytes(raw); p = self.loop / 'pred_old_region.bin'
        p.write_bytes(bytes([2]) + p.read_bytes()[1:])
        with self.assertRaisesRegex(ValueError, 'baseline'): self.check()

    def test_missing_raw_input_and_overlapping_train_test_fail(self):
        self.paths['cube'].unlink()
        with self.assertRaisesRegex(ValueError, 'cube'): self.check()
        self.paths['cube'].write_bytes(b'cube')
        savemat(self.paths['test'], {'data': self.gt})
        with self.assertRaisesRegex(ValueError, 'Train.*Test'): self.check()

    def test_annotation_count_preserves_holdout_and_input_drift_is_detected(self):
        for count in [True, 0, 91]:
            with self.assertRaises(ValueError): self.check(annotate=count)
        receipt = self.check(); self.ckpt.write_bytes(b'new content')
        with self.assertRaisesRegex(ValueError, 'changed'): guard.unchanged(receipt)

    def test_cli_rejects_missing_input_before_scene_preprocessing(self):
        import finetune_region as train
        from types import SimpleNamespace
        args = SimpleNamespace(scene='longkou', hold_class=3, model='unoverlapping', seed=0,
            per_class=100, val_per_class=10, annotate=30, weights_version='new', run_tag='new', preflight=None)
        with patch.object(train, 'ROOT', self.root), patch.object(train, 'load_scene') as load:
            (self.loop / 'gt_region.bin').unlink()
            with self.assertRaisesRegex(ValueError, 'gt_region'): train.cmd_finetune(args)
            load.assert_not_called()

    def test_service_rejects_missing_baseline_before_claim_thread_or_popen(self):
        import server as s
        from types import SimpleNamespace
        state = SimpleNamespace(finetune=None)
        (self.loop / 'pred_old_region.bin').unlink()
        cmd = dict(scene='longkou', base_version='hold3', rect=[0, 0, 64, 64], annotate=30)
        with patch.object(s, 'S', state), patch.object(s, 'ROOT', self.root), \
             patch.object(s.E, 'closed_loop_info', return_value=dict(region=self.info)), \
             patch.object(s.threading, 'Thread') as thread, patch.object(s.subprocess, 'Popen') as proc:
            with self.assertRaisesRegex(ValueError, 'pred_old_region'): s.finetune(cmd)
            self.assertIsNone(state.finetune); thread.assert_not_called(); proc.assert_not_called()
        self.assertFalse((self.root / 'build/host/gcs_training').exists())


class EquivalenceTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name); self.data = self.root / 'data/scenes'
        self.existing = exported(self.root, 'v3_board')
        self.fresh = exported(self.root, 'live1012_093738', b'another serialized checkpoint')
        self.versions = [dict(id='v3', pkg='v3_board', ckpt='old.pth')]

    def test_all_six_files_equivalent_keep_both_sources_without_retagging(self):
        before = {p: p.read_bytes() for d in [self.existing, self.fresh] for p in d.iterdir()}
        r = models.export_reuse(self.data, 'longkou', 'live1012_093738', self.versions)
        self.assertEqual((r['status'], r['version'], r['tag']), ('equivalent', 'v3', 'v3_board'))
        self.assertEqual(len(r['files']), 6)
        self.assertNotEqual(r['export_provenance']['checkpoint_sha256'], r['reuse_provenance']['checkpoint_sha256'])
        self.assertEqual(before, {p: p.read_bytes() for d in [self.existing, self.fresh] for p in d.iterdir()})

    def test_one_crc_equal_is_not_byte_equivalence_or_permission_to_upload_alias(self):
        a, b = fixture(); a = bytearray(a); a[-1] = 1
        exported(self.root, 'live1012_093738', b'new', (bytes(a), b))
        r = models.export_reuse(self.data, 'longkou', 'live1012_093738', self.versions)
        self.assertEqual(r['status'], 'crc_conflict')
        self.assertIsNone(r['version'])

    def test_forged_equal_file_hashes_are_rejected_and_missing_package_is_not_reused(self):
        p = self.fresh / 'classifier_b.bin'; p.write_bytes(bytes([1]) + p.read_bytes()[1:])
        with self.assertRaisesRegex(ValueError, 'SHA256'):
            models.export_reuse(self.data, 'longkou', 'live1012_093738', self.versions)
        exported(self.root, 'live1012_093738'); (self.existing / 'classifier_b.bin').unlink()
        self.assertEqual(models.export_reuse(self.data, 'longkou', 'live1012_093738', self.versions)['status'], 'new')

    def test_catalog_restart_keeps_run_provenance_but_does_not_add_upload_alias(self):
        import engine as e
        versions = {'longkou': copy.deepcopy(self.versions)}
        with patch.object(e, 'DATA', self.data), patch.object(e, 'VERSIONS', versions), patch.object(e, 'EXPORT_REUSE', {}):
            self.assertEqual(e.discover_board_exports(), [])
            self.assertEqual([v['id'] for v in versions['longkou']], ['v3'])
            self.assertEqual(e.EXPORT_REUSE['longkou/live1012_093738']['version'], 'v3')

    def test_service_returns_canonical_version_and_keeps_new_run_candidate_receipt(self):
        import io
        from types import SimpleNamespace
        from unittest.mock import Mock
        import server as s
        tag = 'live1012_123456'; events = []; state = SimpleNamespace(finetune=None)
        process = Mock(); process.returncode = 0; process.poll.return_value = 0
        process.stdout = io.StringIO(json.dumps(dict(new_ckpt='fixture.pth',
            new_ckpt_sha256=hashlib.sha256(b'new run').hexdigest())) + '\n')
        def launch(*args, **kwargs):
            exported(self.root, tag, b'new run'); return process
        recipe = dict(region=dict(hold_class=3, region=dict(row0=0, col0=0, size=64)))
        versions = {'longkou': copy.deepcopy(self.versions)}
        with patch.object(s, 'S', state), patch.object(s, 'ROOT', self.root), \
             patch.object(s.E, 'DATA', self.data), patch.object(s.E, 'VERSIONS', versions), \
             patch.object(s.E, 'EXPORT_REUSE', {}), patch.object(s.E, 'closed_loop_info', return_value=recipe), \
             patch.object(s.finetune_guard, 'preflight', return_value=dict(schema=1, inputs=[])), \
             patch.object(s.time, 'strftime', return_value=tag), \
             patch.object(s.threading, 'Thread', side_effect=lambda **kw: SimpleNamespace(start=kw['target'])), \
             patch.object(s.subprocess, 'Popen', side_effect=launch), patch.object(s, 'emit_json', side_effect=events.append):
            s.finetune(dict(scene='longkou', base_version='hold3', rect=[0, 0, 64, 64], annotate=30))
        done = next(e for e in events if e.get('type') == 'finetune' and e.get('state') == 'done')
        self.assertEqual((done['tag'], done['candidate']['version'], done['candidate']['package_tag']), (tag, 'v3', 'v3_board'))
        self.assertTrue(done['candidate']['reuse']); self.assertIsNone(state.finetune)
        self.assertEqual([v['id'] for v in versions['longkou']], ['v3'])
        folder = self.root / 'build/host/gcs_training' / tag
        self.assertEqual(json.loads((folder / 'candidate.json').read_text())['tag'], tag)
        self.assertEqual(json.loads((folder / 'export_reuse.json').read_text())['version'], 'v3')


if __name__ == '__main__': unittest.main()
